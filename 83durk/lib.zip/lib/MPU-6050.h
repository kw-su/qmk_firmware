#pragma once

void MPU6050_pointing(void);
void MPU6050_data (int16_t *get_data);